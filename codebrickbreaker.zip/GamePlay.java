import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GamePlay extends JPanel implements KeyListener, ActionListener {

     private boolean play = false;
     private int score = 0;
     private int totalBricks = 40;

     private Timer timer;
     private int delay = 8;

     private int playerX = 310;
     private int ballPosX = 120;
     private int ballPosY = 350;
     private int ballXDir = -1;
     private int ballYDir = -2;

     private MapGenerator map;

     public GamePlay() {
          map = new MapGenerator(3, 10);
          addKeyListener(this);
          setFocusable(true);
          setFocusTraversalKeysEnabled(false);
          timer = new Timer(delay, this);
          timer.start();
     }

     // Override paint method and other required methods here
     @Override
     public void paint(Graphics g) {
          // Background
          g.setColor(Color.black);
          g.fillRect(1, 1, 692, 592);

          // Drawing bricks
          map.draw((Graphics2D) g);

          // Scores
          g.setColor(Color.white);
          g.setFont(new Font("serif", Font.BOLD, 25));
          g.drawString("" + score, 590, 30);

          // The paddle
          g.setColor(Color.MAGENTA);
          g.fillRect(playerX, 550, 100, 8);

          // The ball
          g.setColor(Color.orange);
          g.fillOval(ballPosX, ballPosY, 20, 20);

          // Other necessary code for repainting and game over
          g.dispose();
     }

     @Override
     public void actionPerformed(ActionEvent e) {
          timer.start();

          if (play) {
               // Detect collision with the paddle
               if (new Rectangle(ballPosX, ballPosY, 20, 20).intersects(new Rectangle(playerX, 550, 100, 8))) {
                    ballYDir = -ballYDir;
               }

               // Collision detection for bricks
               A: for (int i = 0; i < map.map.length; i++) {
                    for (int j = 0; j < map.map[0].length; j++) {
                         if (map.map[i][j] > 0) {
                              int brickX = j * map.brickWidth + 80;
                              int brickY = i * map.brickHeight + 50;
                              int brickWidth = map.brickWidth;
                              int brickHeight = map.brickHeight;

                              Rectangle rect = new Rectangle(brickX, brickY, brickWidth, brickHeight);
                              Rectangle ballRect = new Rectangle(ballPosX, ballPosY, 20, 20);
                              Rectangle brickRect = rect;

                              if (ballRect.intersects(brickRect)) {
                                   map.setBrickValue(0, i, j);
                                   totalBricks--;
                                   score += 5;

                                   // Adjust ball speed based on remaining bricks
                                   increaseBallSpeed();

                                   if (ballPosX + 19 <= brickRect.x || ballPosX + 1 >= brickRect.x + brickRect.width) {
                                        ballXDir = -ballXDir;
                                   } else {
                                        ballYDir = -ballYDir;
                                   }

                                   break A;
                              }
                         }
                    }
               }

               // Ball movement logic
               ballPosX += ballXDir;
               ballPosY += ballYDir;

               // Check for wall collisions
               if (ballPosX < 0) {
                    ballXDir = -ballXDir;
               }
               if (ballPosY < 0) {
                    ballYDir = -ballYDir;
               }
               if (ballPosX > 670) {
                    ballXDir = -ballXDir;
               }

               repaint();
          }
     }

     @Override
     public void keyPressed(KeyEvent e) {
          if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
               if (playerX >= 600) {
                    playerX = 600;
               } else {
                    moveRight();
               }
          }
          if (e.getKeyCode() == KeyEvent.VK_LEFT) {
               if (playerX < 10) {
                    playerX = 10;
               } else {
                    moveLeft();
               }
          }
     }

     public void moveRight() {
          play = true;
          playerX += 20;
     }

     public void moveLeft() {
          play = true;
          playerX -= 20;
     }

     @Override
     public void keyTyped(KeyEvent e) {
          throw new UnsupportedOperationException("Not supported yet."); // Generated from
                                                                         // nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
     }

     @Override
     public void keyReleased(KeyEvent e) {
          throw new UnsupportedOperationException("Not supported yet."); // Generated from
                                                                         // nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
     }

     public void increaseBallSpeed() {
          // Example: Increase speed as bricks decrease
          int speedIncrement = 1; // Define how much to increase

          if (totalBricks % 5 == 0 && totalBricks > 0) { // Increase speed every 5 bricks
               if (ballXDir > 0) {
                    ballXDir += speedIncrement;
               } else {
                    ballXDir -= speedIncrement;
               }

               if (ballYDir > 0) {
                    ballYDir += speedIncrement;
               } else {
                    ballYDir -= speedIncrement;
               }
          }
     }

}
